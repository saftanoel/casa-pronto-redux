import { useState, useMemo, useEffect, useTransition } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { MapPin, Bed, Bath, Square, ArrowRight, Search, Phone, Mail, ChevronRight, Grid3X3, List, SlidersHorizontal, Loader2 } from "lucide-react";
import PropertyImageCarousel from "@/components/PropertyImageCarousel";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerClose } from "@/components/ui/drawer";
import { cn } from "@/lib/utils";
import { type Property } from "@/data/properties";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { SearchProvider } from "@/context/SearchContext";
import { useInitialProperties, useAllProperties, useTaxonomies } from "@/hooks/useProperties";
import { PropertyGridSkeletons, PropertyRowSkeletons } from "@/components/PropertyCardSkeleton";
import { matchesTaxonomy } from "@/hooks/useTaxonomyOptions";
import { useDebounce } from "@/hooks/useDebounce";

type FilterTab = "toate" | "cumparare" | "inchiriere" | "vandute";
type ViewMode = "grid" | "list";
type SortOption = "newest" | "oldest" | "price-high" | "price-low";

function toSlug(str: string): string {
  return str
    .toLowerCase()
    .replace(/ă/g, "a").replace(/â/g, "a").replace(/î/g, "i")
    .replace(/ș/g, "s").replace(/ț/g, "t")
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9-]/g, "");
}

function matchTab(p: Property, tab: FilterTab): boolean {
  if (tab === "toate") return true;
  const statuses = p.taxonomies?.property_status ?? [];
  const statusSlugs = statuses.map(s => s.toLowerCase());
  switch (tab) {
    case "cumparare": return statusSlugs.some(s => s.includes("cumpar") || s.includes("vanzar") || s.includes("vânzar"));
    case "inchiriere": return statusSlugs.some(s => s.includes("inchiri") || s.includes("închiri"));
    case "vandute": return statusSlugs.some(s => s.includes("vandu") || s.includes("vându") || s.includes("vandut") || s.includes("vândut"));
    default: return true;
  }
}

const PropertyRow = ({ property, search }: { property: Property; search: string }) => (
  <Link to={`/proprietate/${property.id}${search}`} className="block">
    <article className="bg-card rounded-xl overflow-hidden shadow-[var(--card-shadow)] hover:shadow-[var(--card-shadow-hover)] transition-all duration-300 flex flex-col md:flex-row animate-fade-up">
      <PropertyImageCarousel
        images={property.images?.length > 0 ? property.images : [property.image]}
        alt={property.title}
        className="md:w-80 flex-shrink-0"
        aspectClass="aspect-[4/3] md:aspect-auto md:min-h-[200px]"
      >
        <div className="absolute top-3 left-3 flex gap-2 pointer-events-none z-[5]">
          <Badge variant={property.type === "Vânzare" ? "default" : property.type === "Închiriere" ? "secondary" : "outline"}
            className={cn("text-xs", property.type === "Vândut" && "bg-foreground/80 text-background")}>
            {property.type}
          </Badge>
          {property.isNew && <Badge className="bg-accent text-accent-foreground text-xs">Nou</Badge>}
        </div>
      </PropertyImageCarousel>
      <div className="flex-1 p-5 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-muted-foreground text-sm mb-1">
            <MapPin className="h-3.5 w-3.5" />
            <span>{property.location}</span>
          </div>
          <h3 className="font-serif text-lg font-semibold text-foreground hover:text-primary transition-colors">
            {property.title}
          </h3>
          <p className="text-muted-foreground text-sm mt-2 line-clamp-2">
            Agentia Imobiliară Casa Pronto oferă spre {property.type === "Închiriere" ? "închiriere" : "vânzare"} {property.title.toLowerCase()}, zona {property.location.split(",")[0]}. Suprafața imobilului este de {property.area} mp.
          </p>
        </div>
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
          <div className="flex items-center gap-5">
            <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <Square className="h-4 w-4" />
              <span>{property.area} m²</span>
            </div>
            {property.beds > 0 && (
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <Bed className="h-4 w-4" />
                <span>{property.beds} Camere</span>
              </div>
            )}
            <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <Bath className="h-4 w-4" />
              <span>{property.baths} Băi</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="font-bold text-xl text-primary">
              {property.price}
              {property.type === "Închiriere" && <span className="text-sm font-normal text-muted-foreground">/lună</span>}
            </span>
            <ArrowRight className="h-4 w-4 text-muted-foreground" />
          </div>
        </div>
      </div>
    </article>
  </Link>
);

const PropertyGrid = ({ property, search }: { property: Property; search: string }) => (
  <Link to={`/proprietate/${property.id}${search}`} className="block">
    <article className="bg-card rounded-xl overflow-hidden shadow-[var(--card-shadow)] hover:shadow-[var(--card-shadow-hover)] transition-all duration-300 animate-fade-up">
      <PropertyImageCarousel
        images={property.images?.length > 0 ? property.images : [property.image]}
        alt={property.title}
        aspectClass="aspect-[4/3]"
      >
        <div className="absolute top-3 left-3 flex gap-2 pointer-events-none z-[5]">
          <Badge variant={property.type === "Vânzare" ? "default" : property.type === "Închiriere" ? "secondary" : "outline"}
            className={cn("text-xs", property.type === "Vândut" && "bg-foreground/80 text-background")}>
            {property.type}
          </Badge>
          {property.isNew && <Badge className="bg-accent text-accent-foreground text-xs">Nou</Badge>}
        </div>
        <div className="absolute bottom-3 left-3 pointer-events-none z-[5]">
          <p className="text-background font-bold text-xl drop-shadow-lg">
            {property.price}
            {property.type === "Închiriere" && <span className="text-sm font-normal">/lună</span>}
          </p>
        </div>
      </PropertyImageCarousel>
      <div className="p-4">
        <h3 className="font-serif text-base font-semibold text-foreground line-clamp-1 hover:text-primary transition-colors">{property.title}</h3>
        <div className="flex items-center gap-1.5 text-muted-foreground mt-1.5">
          <MapPin className="h-3.5 w-3.5" />
          <span className="text-sm">{property.location}</span>
        </div>
        <div className="flex items-center gap-4 mt-3 pt-3 border-t border-border">
          {property.beds > 0 && (
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Bed className="h-3.5 w-3.5" />
              <span>{property.beds}</span>
            </div>
          )}
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Bath className="h-3.5 w-3.5" />
            <span>{property.baths}</span>
          </div>
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Square className="h-3.5 w-3.5" />
            <span>{property.area} mp</span>
          </div>
          <ArrowRight className="ml-auto h-3.5 w-3.5 text-muted-foreground" />
        </div>
      </div>
    </article>
  </Link>
);

interface FilterSelectsProps {
  mobile?: boolean;
  category: string;
  setCategory: (v: string) => void;
  propertyTypes: { value: string; label: string }[];
  zone: string;
  setZone: (v: string) => void;
  zones: { value: string; label: string }[];
  searchQuery: string;
  setSearchQuery: (v: string) => void;
}

const FilterSelects = ({ mobile = false, category, setCategory, propertyTypes, zone, setZone, zones, searchQuery, setSearchQuery }: FilterSelectsProps) => {
  const h = mobile ? "h-11" : "h-10";
  return (
    <>
      <div>
        <label className="text-sm font-medium text-foreground mb-1.5 block">Categorie</label>
        <Select value={category || "all"} onValueChange={(v) => setCategory(v === "all" ? "" : v)}>
          <SelectTrigger className={h}>
            <SelectValue placeholder="Toate" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Toate</SelectItem>
            {propertyTypes.map((c) => (
              <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <label className="text-sm font-medium text-foreground mb-1.5 block">Zonă</label>
        <Select value={zone || "all"} onValueChange={(v) => setZone(v === "all" ? "" : v)}>
          <SelectTrigger className={h}>
            <SelectValue placeholder="Toate" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Toate</SelectItem>
            {zones.map((z) => (
              <SelectItem key={z.value} value={z.value}>{z.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <label className="text-sm font-medium text-foreground mb-1.5 block">Caută</label>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Caută anunțuri..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={mobile ? (e) => setTimeout(() => e.target.scrollIntoView({ behavior: "smooth", block: "center" }), 300) : undefined}
            className={cn("pl-10 text-base md:text-sm w-full max-w-full box-border", h)}
          />
        </div>
      </div>
    </>
  );
};

const ITEMS_PER_PAGE = 12;

const PropertiesPage = () => {
  // Fetch 1: Initial 60 properties (instant)
  const { data: initialProperties = [], isLoading: isLoadingInitial } = useInitialProperties(60);
  // Fetch 2: Taxonomies — independent, instant, populates dropdowns immediately
  const { data: taxonomyData } = useTaxonomies();
  // Fetch 3: All ~5000 properties (background)
  const { data: allPropertiesFull, isFetched: isAllFetched } = useAllProperties(true);

  // Determine which dataset to use for filtering
  const hasFullData = isAllFetched && !!allPropertiesFull;
  const allProperties = hasFullData ? allPropertiesFull : initialProperties;

  // Debug logs
  useEffect(() => {
    if (taxonomyData) {
      console.log('Taxonomies loaded:', taxonomyData);
    }
  }, [taxonomyData]);

  useEffect(() => {
    if (allPropertiesFull) {
      console.log('Background fetch complete, total items:', allPropertiesFull.length);
    }
  }, [allPropertiesFull]);

  // Dropdown options — populated INSTANTLY from /taxonomii endpoint, independent of properties
  const zones = useMemo(() =>
    (taxonomyData?.property_city ?? []).map((label: string) => ({ value: toSlug(label), label })).sort((a: {label:string}, b: {label:string}) => a.label.localeCompare(b.label, "ro")),
    [taxonomyData]
  );
  const propertyTypes = useMemo(() =>
    (taxonomyData?.property_type ?? []).map((label: string) => ({ value: toSlug(label), label })).sort((a: {label:string}, b: {label:string}) => a.label.localeCompare(b.label, "ro")),
    [taxonomyData]
  );
  const statuses = useMemo(() =>
    (taxonomyData?.property_status ?? []).map((label: string) => ({ value: toSlug(label), label })).sort((a: {label:string}, b: {label:string}) => a.label.localeCompare(b.label, "ro")),
    [taxonomyData]
  );

  const [searchParams, setSearchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState<FilterTab>((searchParams.get("tab") as FilterTab) || "toate");
  const [searchQuery, setSearchQuery] = useState(searchParams.get("q") || "");
  const debouncedSearch = useDebounce(searchQuery, 300);
  const [zone, setZone] = useState(searchParams.get("zone") || "");
  const [category, setCategory] = useState(searchParams.get("category") || "");
  const [rooms, setRooms] = useState(searchParams.get("rooms") || "");
  const [area, setArea] = useState(searchParams.get("area") || "");
  const [price, setPrice] = useState(searchParams.get("price") || "");
  const [sortBy, setSortBy] = useState<SortOption>("newest");
  const [viewMode, setViewMode] = useState<ViewMode>("list");
  const [isFilterDrawerOpen, setIsFilterDrawerOpen] = useState(false);
  const [visibleCount, setVisibleCount] = useState(ITEMS_PER_PAGE);
  const [isPending, startTransition] = useTransition();

  // Track if user has applied any filter that requires taxonomy data (full dataset)
  const hasTaxonomyFilter = !!(zone || category || activeTab !== "toate");
  // Track if user has applied ANY filter at all
  const hasActiveFilter = !!(zone || category || rooms || area || price || debouncedSearch || activeTab !== "toate");

  // "Eager user" state: user applied a taxonomy filter before full data loaded
  // Only show overlay for taxonomy-dependent filters since initial 60 have empty taxonomies
  const isWaitingForFullData = hasTaxonomyFilter && !hasFullData && !isLoadingInitial;

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Sync filters from URL params (but NOT searchQuery — that's controlled by the input directly
  // to avoid a circular loop: type → debounce → setSearchParams → setSearchQuery → reset keyboard)
  useEffect(() => {
    setCategory(searchParams.get("category") || "");
    setZone(searchParams.get("zone") || "");
    setActiveTab((searchParams.get("tab") as FilterTab) || "toate");
    setRooms(searchParams.get("rooms") || "");
    setArea(searchParams.get("area") || "");
    setPrice(searchParams.get("price") || "");
  }, [searchParams]);

  useEffect(() => {
    const params = new URLSearchParams();
    if (activeTab && activeTab !== "toate") params.set("tab", activeTab);
    if (zone) params.set("zone", zone);
    if (category) params.set("category", category);
    if (rooms) params.set("rooms", rooms);
    if (area) params.set("area", area);
    if (price) params.set("price", price);
    if (debouncedSearch) params.set("q", debouncedSearch);
    setSearchParams(params, { replace: true });
  }, [activeTab, zone, category, rooms, area, price, debouncedSearch]);

  const currentSearch = useMemo(() => {
    const params = new URLSearchParams();
    if (activeTab && activeTab !== "toate") params.set("tab", activeTab);
    if (zone) params.set("zone", zone);
    if (category) params.set("category", category);
    if (rooms) params.set("rooms", rooms);
    if (area) params.set("area", area);
    if (price) params.set("price", price);
    if (debouncedSearch) params.set("q", debouncedSearch);
    const qs = params.toString();
    return qs ? `?${qs}` : "";
  }, [activeTab, zone, category, rooms, area, price, debouncedSearch]);

  const resetAllFilters = () => {
    startTransition(() => {
      setActiveTab("toate");
      setSearchQuery("");
      setZone("");
      setCategory("");
      setRooms("");
      setArea("");
      setPrice("");
      setVisibleCount(ITEMS_PER_PAGE);
    });
  };

  useEffect(() => {
    setVisibleCount(ITEMS_PER_PAGE);
  }, [activeTab, zone, category, rooms, area, price, debouncedSearch, sortBy]);

  const tabs: { id: FilterTab; label: string }[] = [
    { id: "toate", label: "TOATE" },
    { id: "cumparare", label: "CUMPĂRĂRI" },
    { id: "inchiriere", label: "ÎNCHIRIERI" },
    { id: "vandute", label: "VÂNDUTE" },
  ];

  const filteredProperties = useMemo(() => {
    // Use full data when available; otherwise use initial 60
    // Note: initial 60 have empty taxonomies, so taxonomy filters won't match them
    const sourceData = allPropertiesFull ?? initialProperties;

    let result = sourceData.filter((p) => {
      if (!matchTab(p, activeTab)) return false;
      if (zone && !matchesTaxonomy(p, "property_city", zone)) return false;
      if (category && !matchesTaxonomy(p, "property_type", category)) return false;
      if (rooms) {
        if (rooms === "4+") { if (p.beds < 4) return false; }
        else { if (p.beds !== parseInt(rooms)) return false; }
      }
      if (area) {
        const a = p.area;
        const areaRanges: Record<string, [number, number]> = {
          "sub-1000": [0, 1000], "1000-2000": [1000, 2000], "2000-3000": [2000, 3000],
          "3000-4000": [3000, 4000], "4000-5000": [4000, 5000], "5000-6000": [5000, 6000],
          "6000-7000": [6000, 7000], "7000-8000": [7000, 8000], "peste-8000": [8000, Infinity],
        };
        const range = areaRanges[area];
        if (range && (a < range[0] || a >= range[1])) return false;
      }
      if (price) {
        const pv = p.priceValue;
        const priceRanges: Record<string, [number, number]> = {
          "sub-200": [0, 200], "200-300": [200, 300], "300-400": [300, 400],
          "400-500": [400, 500], "500-700": [500, 700], "700-1000": [700, 1000], "peste-1000": [1000, Infinity],
          "sub-25000": [0, 25000], "25000-50000": [25000, 50000], "50000-75000": [50000, 75000],
          "75000-100000": [75000, 100000], "100000-150000": [100000, 150000],
          "150000-200000": [150000, 200000], "200000-300000": [200000, 300000], "peste-300000": [300000, Infinity],
        };
        const range = priceRanges[price];
        if (range && (pv < range[0] || pv >= range[1])) return false;
      }
      if (debouncedSearch) {
        const q = debouncedSearch.toLowerCase();
        if (!p.title.toLowerCase().includes(q) && !p.location.toLowerCase().includes(q) && !p.description.toLowerCase().includes(q))
          return false;
      }
      return true;
    });

    switch (sortBy) {
      case "price-high": result.sort((a, b) => b.priceValue - a.priceValue); break;
      case "price-low": result.sort((a, b) => a.priceValue - b.priceValue); break;
      case "oldest": result.sort((a, b) => new Date(a.date || 0).getTime() - new Date(b.date || 0).getTime()); break;
      default: result.sort((a, b) => new Date(b.date || 0).getTime() - new Date(a.date || 0).getTime()); break;
    }

    return result;
  }, [activeTab, zone, category, rooms, area, price, debouncedSearch, sortBy, allProperties, initialProperties, allPropertiesFull, hasActiveFilter]);

  const getCategoryLabel = () => {
    if (category) {
      const cat = propertyTypes.find(c => c.value === category);
      return cat?.label || "Anunțuri Imobiliare";
    }
    return "Anunțuri Imobiliare";
  };

  const visibleProperties = useMemo(
    () => filteredProperties.slice(0, visibleCount),
    [filteredProperties, visibleCount]
  );
  const hasMoreLocal = visibleCount < filteredProperties.length;

  const filterSelectsProps = { category, setCategory, propertyTypes, zone, setZone, zones, searchQuery, setSearchQuery };


  return (
    <SearchProvider properties={initialProperties} isLoading={isLoadingInitial}>
      <div className="min-h-screen flex flex-col">
        <Header />

        {/* Page Header */}
        <div className="bg-muted/50 pt-36 pb-8 border-b border-border">
          <div className="container mx-auto px-4">
            <h1 className="font-serif text-3xl md:text-4xl font-bold">{getCategoryLabel()} Alba Iulia</h1>
            <nav className="flex items-center gap-2 mt-3 text-sm text-muted-foreground">
              <Link to="/" className="hover:text-primary transition-colors">Casa Pronto</Link>
              <ChevronRight className="h-3.5 w-3.5" />
              <Link to="/proprietati" onClick={resetAllFilters} className="hover:text-primary transition-colors">Anunțuri Imobiliare</Link>
              {category && (
                <>
                  <ChevronRight className="h-3.5 w-3.5" />
                  <span className="text-foreground">{getCategoryLabel()}</span>
                </>
              )}
            </nav>
          </div>
        </div>

        {/* Tabs + Sort Bar */}
        <div className="bg-background border-b border-border sticky top-[calc(2rem+5rem)] z-30">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between py-3 gap-3">
              <div className="flex gap-2 bg-muted/40 p-1 rounded-xl overflow-x-auto scrollbar-hide -mx-4 px-4 md:mx-0 md:px-0 flex-shrink-0">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => startTransition(() => setActiveTab(tab.id))}
                    disabled={isPending}
                    className={cn(
                      "flex-shrink-0 whitespace-nowrap px-5 py-2.5 text-sm font-medium tracking-wider rounded-lg transition-all duration-200 font-serif min-h-[44px]",
                      activeTab === tab.id
                        ? "bg-primary text-primary-foreground shadow-md"
                        : "text-muted-foreground hover:text-primary hover:bg-primary/10",
                      isPending && "opacity-70 cursor-wait"
                    )}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
              <div className="hidden md:flex items-center gap-3">
                <span className="text-sm text-muted-foreground">Sortează:</span>
                <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortOption)}>
                  <SelectTrigger className="w-44 h-9 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Nou → Vechi</SelectItem>
                    <SelectItem value="oldest">Vechi → Nou</SelectItem>
                    <SelectItem value="price-high">Preț (Mare - Mic)</SelectItem>
                    <SelectItem value="price-low">Preț (Mic - Mare)</SelectItem>
                  </SelectContent>
                </Select>
                <div className="flex border border-border rounded-md overflow-hidden">
                  <button
                    onClick={() => setViewMode("list")}
                    className={cn("p-2 transition-colors", viewMode === "list" ? "bg-primary text-primary-foreground" : "hover:bg-muted")}
                  >
                    <List className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => setViewMode("grid")}
                    className={cn("p-2 transition-colors", viewMode === "grid" ? "bg-primary text-primary-foreground" : "hover:bg-muted")}
                  >
                    <Grid3X3 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 bg-background py-8">
          <div className="container mx-auto px-4">
            {/* Mobile Filter Button */}
            <div className="lg:hidden mb-4">
              <Button
                variant="outline"
                className="w-full gap-2"
                onClick={() => setIsFilterDrawerOpen(true)}
              >
                <SlidersHorizontal className="h-4 w-4" />
                Filtrează
                {(category || zone || debouncedSearch) && (
                  <Badge variant="secondary" className="ml-auto text-xs">
                    {[category, zone, debouncedSearch].filter(Boolean).length}
                  </Badge>
                )}
              </Button>
            </div>

            <div className="flex flex-col lg:flex-row gap-8">
              {/* Sidebar - desktop only */}
              <aside className="hidden lg:block w-80 flex-shrink-0 space-y-6 order-last">
                <div className="bg-card rounded-xl p-6 shadow-[var(--card-shadow)] border border-border">
                  <h3 className="font-serif font-semibold text-lg mb-5">Filtre</h3>
                  <div className="space-y-4">
                    <FilterSelects {...filterSelectsProps} />
                    <Button className="w-full gap-2" onClick={() => {}}>
                      <Search className="h-4 w-4" />
                      CAUTĂ ANUNȚURI
                    </Button>
                  </div>
                </div>
                <div className="bg-card rounded-xl p-6 shadow-[var(--card-shadow)] border border-border">
                  <h3 className="font-serif font-semibold text-lg text-primary mb-1">Casa Pronto</h3>
                  <div className="w-12 h-1 bg-primary rounded-full mb-5" />
                  <div className="space-y-4 text-sm">
                    <div className="flex items-start gap-3">
                      <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                      <span>Alba Iulia, Calea Moților, Nr 59C</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Phone className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                      <a href="tel:0740197476" className="hover:text-primary transition-colors">0740197476</a>
                    </div>
                    <div className="flex items-center gap-3">
                      <Mail className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                      <a href="mailto:casa_pronto@yahoo.com" className="hover:text-primary transition-colors">casa_pronto@yahoo.com</a>
                    </div>
                  </div>
                </div>
              </aside>

              {/* Property List */}
              <div className="flex-1 relative">
                <p className="text-sm text-muted-foreground mb-6">
                  {isLoadingInitial ? "Se încarcă..." : (
                    <>
                      {filteredProperties.length} proprietăți
                      {!hasFullData && hasActiveFilter && <span className="ml-1 text-primary">(se încarcă toate...)</span>}
                      {hasFullData && ` din ${allPropertiesFull!.length}`}
                    </>
                  )}
                  {isPending && <span className="ml-2 text-primary">Se actualizează...</span>}
                </p>

                {/* Eager User Loading Overlay */}
                {isWaitingForFullData && (
                  <div className="absolute inset-0 z-20 bg-background/80 backdrop-blur-sm rounded-xl flex flex-col items-center justify-center gap-4 min-h-[400px]">
                    <Loader2 className="h-10 w-10 text-primary animate-spin" />
                    <p className="text-lg font-serif font-medium text-foreground">Căutăm prin toate ofertele...</p>
                    
                  </div>
                )}

                {isLoadingInitial ? (
                  viewMode === "list" ? (
                    <div className="flex flex-col gap-6">
                      <PropertyRowSkeletons count={4} />
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <PropertyGridSkeletons count={6} />
                    </div>
                  )
                ) : filteredProperties.length > 0 ? (
                  <>
                    {viewMode === "list" ? (
                      <div className="flex flex-col gap-6">
                        {visibleProperties.map((property) => (
                          <PropertyRow key={property.id} property={property} search={currentSearch} />
                        ))}
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {visibleProperties.map((property) => (
                          <PropertyGrid key={property.id} property={property} search={currentSearch} />
                        ))}
                      </div>
                    )}

                    {/* Load More Button */}
                    <div className="flex justify-center py-8">
                      {hasMoreLocal ? (
                        <Button
                          variant="outline"
                          size="lg"
                          onClick={() => setVisibleCount((c) => c + ITEMS_PER_PAGE)}
                          className="gap-2 min-h-[44px]"
                        >
                          Încarcă Mai Multe ({filteredProperties.length - visibleCount} rămase)
                          <ChevronRight className="h-4 w-4 rotate-90" />
                        </Button>
                      ) : allProperties.length > 0 ? (
                        <p className="text-sm text-muted-foreground">Toate proprietățile au fost încărcate</p>
                      ) : null}
                    </div>
                  </>
                ) : (
                  <div className="text-center py-20 bg-muted/30 rounded-xl">
                    <p className="text-muted-foreground text-lg">Nu s-au găsit proprietăți cu filtrele selectate.</p>
                    <Button variant="outline" className="mt-4" onClick={resetAllFilters}>
                      Resetează Filtrele
                    </Button>
                  </div>
                )}
              </div>
            </div>

            {/* Mobile Filter Drawer */}
            <Drawer open={isFilterDrawerOpen} onOpenChange={setIsFilterDrawerOpen}>
              <DrawerContent className="max-h-[70vh]">
                <DrawerHeader className="text-left flex-shrink-0">
                  <DrawerTitle className="font-serif text-lg">Filtre</DrawerTitle>
                </DrawerHeader>
                <div className="px-4 pb-6 overflow-y-auto space-y-4 flex-1">
                  <FilterSelects mobile {...filterSelectsProps} />
                  <div>
                    <label className="text-sm font-medium text-foreground mb-1.5 block">Sortează</label>
                    <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortOption)}>
                      <SelectTrigger className="h-11">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="newest">Nou → Vechi</SelectItem>
                        <SelectItem value="oldest">Vechi → Nou</SelectItem>
                        <SelectItem value="price-high">Preț (Mare - Mic)</SelectItem>
                        <SelectItem value="price-low">Preț (Mic - Mare)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex gap-3 pt-2">
                    <Button variant="outline" className="flex-1" onClick={() => { resetAllFilters(); setIsFilterDrawerOpen(false); }}>
                      Resetează
                    </Button>
                    <DrawerClose asChild>
                      <Button className="flex-1 gap-2">
                        <Search className="h-4 w-4" />
                        Aplică Filtre
                      </Button>
                    </DrawerClose>
                  </div>
                </div>
              </DrawerContent>
            </Drawer>
          </div>
        </div>

        <Footer />
      </div>
    </SearchProvider>
  );
};

export default PropertiesPage;
